"""Tiny math library. divide() and power() are not implemented yet."""

def add(a, b):
    return a + b

def divide(a, b):
    raise NotImplementedError

def power(base, exp):
    raise NotImplementedError
